#pragma once
#include "Bird.h"

class Goose :
    public Bird
{
protected:

private:

public:
    Goose();
    ~Goose();
    void Skill(BirdList*);
};

