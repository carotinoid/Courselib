import random

class Panel:
    def __init__(self):
        self.isRevealed = False
        self.hasFlag = False

    def toggleFlag(self):
        if self.hasFlag: self.hasFlag = False
        else: self.hasFlag = True

    def unveil(self):
        self.isRevealed = True


class EmptyPanel(Panel):
    def __init__(self):
        super().__init__()
        self.numOfNearMines = 0

    def addNumOfNearMines(self):
        self.numOfNearMines += 1

    def unveil(self):
        # super().unveil()
        self.isRevealed = True
        return self.numOfNearMines


class MinePanel(Panel):
    def __init__(self):
        super().__init__()
    def unveil(self):
        # super().unveil()
        self.isRevealed = True
        return -1


class Board:
    def reset(self, numMine, height, width):
        self.oneDimPanels = ['Empty' for _ in range(height * width)]
        for i in range(numMine): self.oneDimPanels[i] = 'Mine'
        random.shuffle(self.oneDimPanels)
        self.panels = [[EmptyPanel() if self.oneDimPanels[j * width + i] == 'Empty' else MinePanel() for i in range(width)] for j in range(height)]

        for j in range(height):
            for i in range(width):
                if isinstance(self.panels[j][i], MinePanel):
                    for y in range(j - 1, j + 2):
                        for x in range(i - 1, i + 2):
                            if 0 <= y < height and 0 <= x < width and isinstance(self.panels[y][x], EmptyPanel):
                                self.panels[y][x].addNumOfNearMines()

    def getNumOfRevealedPanels(self):
        self.numofRevealedPanels = 0
        for row in self.panels:
            for panel in row:
                if panel.isRevealed: self.numofRevealedPanels += 1
        return self.numofRevealedPanels


    def unveil(self, y, x):
        value = self.panels[y][x].unveil()
        if value == -1: return -1
        elif value == 0:
            if 0 <= y - 1 < len(self.panels) and 0 <= x < len(self.panels[0]) and not self.panels[y - 1][x].isRevealed and not self.panels[y - 1][x].hasFlag: self.unveil(y - 1, x)
            if 0 <= y + 1 < len(self.panels) and 0 <= x < len(self.panels[0]) and not self.panels[y + 1][x].isRevealed and not self.panels[y + 1][x].hasFlag: self.unveil(y + 1, x)
            if 0 <= y < len(self.panels) and 0 <= x - 1 < len(self.panels[0]) and not self.panels[y][x - 1].isRevealed and not self.panels[y][x - 1].hasFlag: self.unveil(y, x - 1)
            if 0 <= y < len(self.panels) and 0 <= x + 1 < len(self.panels[0]) and not self.panels[y][x + 1].isRevealed and not self.panels[y][x + 1].hasFlag: self.unveil(y, x + 1)
            # for j in range(y - 1, y + 2):
            #     for i in range(x - 1, x + 2):
            #         if 0 <= j < len(self.panels) and 0 <= i < len(self.panels[0]) and not self.panels[j][i].isRevealed:
            #             self.unveil(j, i)

    def toggleFlag(self, y, x):
        self.panels[y][x].toggleFlag()

    def checkReveal(self, y, x):
        return self.panels[y][x].isRevealed


    def checkFlag(self, y, x):
        return self.panels[y][x].hasFlag

    def checkMine(self, y, x):
        return isinstance(self.panels[y][x], MinePanel)

    def getNumOfNearMines(self, y, x):
        return self.panels[y][x].numOfNearMines
