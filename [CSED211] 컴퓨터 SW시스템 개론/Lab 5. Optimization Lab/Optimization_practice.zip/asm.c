#include<stdio.h>

int main(){
	int no=100;
	int val;
    __asm();
	printf("%d \n", val);
	return 0;
}


